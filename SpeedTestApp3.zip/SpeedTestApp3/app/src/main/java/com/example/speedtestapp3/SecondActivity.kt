package com.example.speedtestapp3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.speedtestapp3.Adapter.HistoryAdapter
import com.example.speedtestapp3.Models.Models
import com.example.speedtestapp3.R
import com.example.speedtestapp3.database.DatabaseHelper
import java.util.ArrayList

class SecondActivity : AppCompatActivity() {
    lateinit var recyclerview: RecyclerView
    internal var selectedFragment: Fragment?=null
    lateinit var SpeedBtn : TextView
    var historyAdapter : HistoryAdapter?=null
    var dbHandler : DatabaseHelper?=null
    var historyList : List<Models> = ArrayList<Models>()
    var linearLayoutManager : LinearLayoutManager?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        dbHandler = DatabaseHelper(this)

        recyclerview = findViewById(R.id.history)
        SpeedBtn = findViewById(R.id.speed)
        SpeedBtn.setOnClickListener {
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
        fetchList()
    }
    fun fetchList(){
        historyList = dbHandler!!.getAllHistory()
        Log.d("HistoryList","${historyList.lastIndex}")
        historyAdapter = HistoryAdapter(historyList,applicationContext)
        linearLayoutManager = LinearLayoutManager(applicationContext)
        recyclerview.layoutManager = linearLayoutManager
        recyclerview.adapter = historyAdapter
        historyAdapter?.notifyDataSetChanged()
    }
}