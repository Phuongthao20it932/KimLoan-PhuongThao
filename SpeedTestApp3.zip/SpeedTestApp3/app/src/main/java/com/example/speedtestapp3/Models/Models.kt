package com.example.speedtestapp3.Models

class Models {
    var ID : Int = 0
    var Date : String = ""
    var Download : String = ""
    var Upload : String = ""
    var Ping : String = ""
}